# Sustainable Finance Quest

A gamified survey prototype: one clear question per screen, points per answer, streak bonuses, levels, and a reward screen at the end.

## Edit the survey
Open `index.html` and edit the `SURVEY` object at the top of the `<script>`:
- `questions` — each has a `type`: `single`, `multi`, `scale` (1–5) or `text`
- `points` — what each question is worth (text questions can also have `bonusChars` / `bonusPoints`)
- `reward` — headline, body and `minPoints` needed to unlock it (placeholder for now)

## Run locally
Just open `index.html` in a browser. No build step.

## Deploy to Vercel via GitHub
1. Create a new GitHub repo and push this folder:
   ```
   git init
   git add .
   git commit -m "Survey Quest prototype"
   git branch -M main
   git remote add origin https://github.com/<you>/survey-quest.git
   git push -u origin main
   ```
2. On vercel.com → **Add New → Project** → import the repo.
3. Framework preset: **Other**. Leave build command and output directory empty. Deploy.

Every push to `main` redeploys automatically.

## Collecting responses (next step)
Right now answers save in the visitor's browser and can be downloaded as JSON from the end screen.
To collect them centrally, set `SUBMIT_URL` in `index.html` to an endpoint (a Vercel API route, Formspree, a Google Apps Script web app, etc.). The page POSTs `{ survey, startedAt, finishedAt, score, answers }` when someone finishes.
